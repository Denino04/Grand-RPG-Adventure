Epic Grand RPG Adventure in text form
https://denino04.github.io/Grand-RPG-Adventure/
